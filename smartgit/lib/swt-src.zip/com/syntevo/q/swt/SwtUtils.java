package com.syntevo.q.swt;

import org.eclipse.swt.*;

/**
 * @author Thomas Singer
 */
public class SwtUtils {
	public static boolean isMac() {
		final String ws = SWT.getPlatform();
		return "carbon".equals(ws) || "cocoa".equals(ws);
	}
}
